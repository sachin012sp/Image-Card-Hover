# Image-Card-Hover
Here you can see how the above project depicts the Card Image with a description on hover implemented using HTML &amp; CSS.
